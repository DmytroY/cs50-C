#include "helpers.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// Convert image to grayscale
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{
    BYTE graylevel;
    for (int r = 0; r < height; r++)
    {
        for (int c = 0; c < width; c++)
        {
            graylevel = round((float)(image[r][c].rgbtBlue + image[r][c].rgbtGreen + image[r][c].rgbtRed) / 3);
            image[r][c].rgbtBlue = graylevel;
            image[r][c].rgbtGreen = graylevel;
            image[r][c].rgbtRed = graylevel;
        }
    }
    return;
}

// Reflect image horizontally
void reflect(int height, int width, RGBTRIPLE image[height][width])
{
    BYTE red, green, blue;
    for (int r = 0; r < height; r++)
    {
        for (int c = 0; c < width / 2; c++)
        {
            red = image[r][c].rgbtRed;
            green = image[r][c].rgbtGreen;
            blue = image[r][c].rgbtBlue;
            
            image[r][c].rgbtBlue = image[r][width - c - 1].rgbtBlue;
            image[r][c].rgbtGreen = image[r][width - c - 1].rgbtGreen;
            image[r][c].rgbtRed = image[r][width - c - 1].rgbtRed;
            
            image[r][width - c - 1].rgbtBlue = blue;
            image[r][width - c - 1].rgbtGreen = green;
            image[r][width - c - 1].rgbtRed = red;
        }
    }
    
    return;
}

// Blur image
void blur(int height, int width, RGBTRIPLE image[height][width])
{
    // alocate memory for image copy
    RGBTRIPLE(*image2)[width] = calloc(height, width * sizeof(RGBTRIPLE));
    
    // copy 'image' to 'image2'
    for (int r = 0; r < height; r++)
    {
        for (int c = 0; c < width; c++)
        {
            image2[r][c].rgbtBlue = image[r][c].rgbtBlue;
            image2[r][c].rgbtGreen = image[r][c].rgbtGreen;
            image2[r][c].rgbtRed = image[r][c].rgbtRed;
        }
    }
    
    // blure corners
    image[0][0].rgbtRed   = round((float)(image2[0][0].rgbtRed   + image2[0][1].rgbtRed +
                                          image2[1][0].rgbtRed   + image2[1][1].rgbtRed) / 4);
    image[0][0].rgbtGreen = round((float)(image2[0][0].rgbtGreen + image2[0][1].rgbtGreen +
                                          image2[1][0].rgbtGreen + image2[1][1].rgbtGreen) / 4);
    image[0][0].rgbtBlue  = round((float)(image2[0][0].rgbtBlue  + image2[0][1].rgbtBlue +
                                          image2[1][0].rgbtBlue  + image2[1][1].rgbtBlue) / 4);
    
    image[height - 1][width - 1].rgbtRed   = round((float)(image2[height - 1][width - 1].rgbtRed + image2[height - 1][width - 2].rgbtRed
            + image2[height - 2][width - 1].rgbtRed +   image2[height - 2][width - 2].rgbtRed) / 4);
    image[height - 1][width - 1].rgbtGreen = round((float)(image2[height - 1][width - 1].rgbtGreen +
            image2[height - 1][width - 2].rgbtGreen + image2[height - 2][width - 1].rgbtGreen +
            image2[height - 2][width - 2].rgbtGreen) / 4);
    image[height - 1][width - 1].rgbtBlue  = round((float)(image2[height - 1][width - 1].rgbtBlue +
            image2[height - 1][width - 2].rgbtBlue + image2[height - 2][width - 1].rgbtBlue +  image2[height - 2][width - 2].rgbtBlue) / 4);
    
    image[0][width - 1].rgbtRed = round((float)(image2[0][width - 1].rgbtRed + image2[0][width - 2].rgbtRed +
                                        image2[1][width - 2].rgbtRed + image2[1][width - 1].rgbtRed) / 4);
    image[0][width - 1].rgbtGreen = round((float)(image2[0][width - 1].rgbtGreen + image2[0][width - 2].rgbtGreen +
                                          image2[1][width - 2].rgbtGreen + image2[1][width - 1].rgbtGreen) / 4);
    image[0][width - 1].rgbtBlue = round((float)(image2[0][width - 1].rgbtBlue + image2[0][width - 2].rgbtBlue +
                                         image2[1][width - 2].rgbtBlue + image2[1][width - 1].rgbtBlue) / 4);
    
    image[height - 1][0].rgbtRed = round((float)(image2[height - 1][0].rgbtRed + image2[height - 1][1].rgbtRed +
                                         image2[height - 2][0].rgbtRed + image2[height - 2][1].rgbtRed) / 4);
    image[height - 1][0].rgbtGreen = round((float)(image2[height - 1][0].rgbtGreen + image2[height - 1][1].rgbtGreen +
                                           image2[height - 2][0].rgbtGreen + image2[height - 2][1].rgbtGreen) / 4);
    image[height - 1][0].rgbtBlue = round((float)(image2[height - 1][0].rgbtBlue + image2[height - 1][1].rgbtBlue +
                                          image2[height - 2][0].rgbtBlue + image2[height - 2][1].rgbtBlue) / 4);
    
    // blure last row
    for (int c = 1; c < width - 1; c++)
    {
        image[height - 1][c].rgbtRed = round((float)(image2[height - 1][c].rgbtRed + image2[height - 1][c - 1].rgbtRed +
                                             image2[height - 1][c + 1].rgbtRed + image2[height - 2][c].rgbtRed +
                                             image2[height - 2][c + 1].rgbtRed + image2[height - 2][c - 1].rgbtRed) / 6);
        image[height - 1][c].rgbtGreen = round((float)(image2[height - 1][c].rgbtGreen + image2[height - 1][c - 1].rgbtGreen +
                                               image2[height - 1][c + 1].rgbtGreen + image2[height - 2][c].rgbtGreen +
                                               image2[height - 2][c + 1].rgbtGreen + image2[height - 2][c - 1].rgbtGreen) / 6);
        image[height - 1][c].rgbtBlue = round((float)(image2[height - 1][c].rgbtBlue + image2[height - 1][c - 1].rgbtBlue +
                                              image2[height - 1][c + 1].rgbtBlue + image2[height - 2][c].rgbtBlue +
                                              image2[height - 2][c + 1].rgbtBlue + image2[height - 2][c - 1].rgbtBlue) / 6);
    }
    
    // blure first row
    for (int c = 1; c < width - 1; c++)
    {
        image[0][c].rgbtRed = round((float)(image2[0][c].rgbtRed + image2[0][c - 1].rgbtRed + image2[0][c + 1].rgbtRed +
                                            image2[1][c].rgbtRed + image2[1][c + 1].rgbtRed + image2[1][c - 1].rgbtRed) / 6);
        image[0][c].rgbtGreen = round((float)(image2[0][c].rgbtGreen + image2[0][c - 1].rgbtGreen + image2[0][c + 1].rgbtGreen +
                                              image2[1][c].rgbtGreen + image2[1][c + 1].rgbtGreen + image2[1][c - 1].rgbtGreen) / 6);
        image[0][c].rgbtBlue = round((float)(image2[0][c].rgbtBlue + image2[0][c - 1].rgbtBlue + image2[0][c + 1].rgbtBlue +
                                             image2[1][c].rgbtBlue + image2[1][c + 1].rgbtBlue + image2[1][c - 1].rgbtBlue) / 6);
    }
    
    // blure first column
    for (int r = 1; r < height - 1; r++)
    {
        image[r][0].rgbtRed = round((float)(image2[r][0].rgbtRed + image2[r - 1][0].rgbtRed + image2[r + 1][0].rgbtRed +
                                            image2[r + 1][1].rgbtRed + image2[r - 1][1].rgbtRed + image2[r][1].rgbtRed) / 6);
        image[r][0].rgbtGreen = round((float)(image2[r][0].rgbtGreen + image2[r - 1][0].rgbtGreen + image2[r + 1][0].rgbtGreen +
                                              image2[r + 1][1].rgbtGreen + image2[r - 1][1].rgbtGreen + image2[r][1].rgbtGreen) / 6);
        image[r][0].rgbtBlue = round((float)(image2[r][0].rgbtBlue + image2[r - 1][0].rgbtBlue + image2[r + 1][0].rgbtBlue +
                                             image2[r + 1][1].rgbtBlue + image2[r - 1][1].rgbtBlue + image2[r][1].rgbtBlue) / 6);
    }
    
    // blure last column
    for (int r = 1; r < height - 1; r++)
    {
        image[r][width - 1].rgbtRed = round((float)(image2[r][width - 1].rgbtRed + image2[r - 1][width - 1].rgbtRed +
                                            image2[r + 1][width - 1].rgbtRed + image2[r + 1][width - 2].rgbtRed +
                                            image2[r - 1][width - 2].rgbtRed + image2[r][width - 2].rgbtRed) / 6);
        image[r][width - 1].rgbtGreen = round((float)(image2[r][width - 1].rgbtGreen + image2[r - 1][width - 1].rgbtGreen +
                                              image2[r + 1][width - 1].rgbtGreen + image2[r + 1][width - 2].rgbtGreen +
                                              image2[r - 1][width - 2].rgbtGreen + image2[r][width - 2].rgbtGreen) / 6);
        image[r][width - 1].rgbtBlue = round((float)(image2[r][width - 1].rgbtBlue + image2[r - 1][width - 1].rgbtBlue +
                                             image2[r + 1][width - 1].rgbtBlue + image2[r + 1][width - 2].rgbtBlue +
                                             image2[r - 1][width - 2].rgbtBlue + image2[r][width - 2].rgbtBlue) / 6);
    }
    
    // blure pixells in the midle
    
    for (int r = 1; r < height - 1; r++)
    {
        for (int c = 1; c < width - 1; c++)
        {
            image[r][c].rgbtBlue = 
                round((float)(image2[r - 1][c - 1].rgbtBlue + image2[r - 1][c].rgbtBlue + image2[r - 1][c + 1].rgbtBlue
                              + image2[r + 0][c - 1].rgbtBlue + image2[r + 0][c].rgbtBlue + image2[r + 0][c + 1].rgbtBlue
                              + image2[r + 1][c - 1].rgbtBlue + image2[r + 1][c].rgbtBlue + image2[r + 1][c + 1].rgbtBlue) / 9);
            
            
            image[r][c].rgbtGreen =
                round((float)(image2[r - 1][c - 1].rgbtGreen + image2[r - 1][c].rgbtGreen + image2[r - 1][c + 1].rgbtGreen
                              + image2[r + 0][c - 1].rgbtGreen + image2[r + 0][c].rgbtGreen + image2[r + 0][c + 1].rgbtGreen
                              + image2[r + 1][c - 1].rgbtGreen + image2[r + 1][c].rgbtGreen + image2[r + 1][c + 1].rgbtGreen) / 9);
            
            image[r][c].rgbtRed =
                round((float)(image2[r - 1][c - 1].rgbtRed + image2[r - 1][c].rgbtRed + image2[r - 1][c + 1].rgbtRed
                              + image2[r + 0][c - 1].rgbtRed + image2[r + 0][c].rgbtRed + image2[r + 0][c + 1].rgbtRed
                              + image2[r + 1][c - 1].rgbtRed + image2[r + 1][c].rgbtRed + image2[r + 1][c + 1].rgbtRed) / 9);
        }
    }
    
    free(image2);
    return;
}

// Detect edges
void edges(int height, int width, RGBTRIPLE image[height][width])
{
    // alocate memory for image copy
    RGBTRIPLE(*image2)[width + 2] = calloc(height + 2, (width + 2) * sizeof(RGBTRIPLE));
    
    // fill image2 border pixels with black
    for (int i = 0; i < (width + 2); i++)
    {
        image2[0][i].rgbtBlue = 0;
        image2[0][i].rgbtGreen = 0;
        image2[0][i].rgbtRed = 0;
        
        image2[height + 1][i].rgbtBlue = 0;
        image2[height + 1][i].rgbtGreen = 0;
        image2[height + 1][i].rgbtRed = 0;
        
    }
    for (int i = 1; i < height + 1; i++)
    {
        image2[i][0].rgbtBlue = 0;
        image2[i][0].rgbtGreen = 0;
        image2[i][0].rgbtRed = 0;
        
        image2[i][width + 1].rgbtBlue = 0;
        image2[i][width + 1].rgbtGreen = 0;
        image2[i][width + 1].rgbtRed = 0;
    }
    
    
    // copy 'image' to 'image2' with shift
    for (int r = 0; r < height; r++)
    {
        for (int c = 0; c < width; c++)
        {
            image2[r + 1][c + 1].rgbtBlue = image[r][c].rgbtBlue;
            image2[r + 1][c + 1].rgbtGreen = image[r][c].rgbtGreen;
            image2[r + 1][c + 1].rgbtRed = image[r][c].rgbtRed;
        }
    }
    
    //  Sobel operator
    int GxR, GxG, GxB, GyR, GyG, GyB, gR, gG, gB;
    for (int r = 1; r < height + 1; r++)
    {
        for (int c = 1; c < width + 1; c++)
        {
            GxR = image2[r - 1][c + 1].rgbtRed   + 2 * image2[r][c + 1].rgbtRed   + image2[r + 1][c + 1].rgbtRed   - 
                  image2[r - 1][c - 1].rgbtRed   - 2 * image2[r][c - 1].rgbtRed   - image2[r + 1][c - 1].rgbtRed;
            GxG = image2[r - 1][c + 1].rgbtGreen + 2 * image2[r][c + 1].rgbtGreen + image2[r + 1][c + 1].rgbtGreen -
                  image2[r - 1][c - 1].rgbtGreen - 2 * image2[r][c - 1].rgbtGreen - image2[r + 1][c - 1].rgbtGreen;
            GxB = image2[r - 1][c + 1].rgbtBlue  + 2 * image2[r][c + 1].rgbtBlue  + image2[r + 1][c + 1].rgbtBlue  -
                  image2[r - 1][c - 1].rgbtBlue  - 2 * image2[r][c - 1].rgbtBlue  - image2[r + 1][c - 1].rgbtBlue;

            GyR = image2[r + 1][c - 1].rgbtRed   + 2 * image2[r + 1][c].rgbtRed   + image2[r + 1][c + 1].rgbtRed   -
                  image2[r - 1][c - 1].rgbtRed   - 2 * image2[r - 1][c].rgbtRed   - image2[r - 1][c + 1].rgbtRed;
            GyG = image2[r + 1][c - 1].rgbtGreen + 2 * image2[r + 1][c].rgbtGreen + image2[r + 1][c + 1].rgbtGreen -
                  image2[r - 1][c - 1].rgbtGreen - 2 * image2[r - 1][c].rgbtGreen - image2[r - 1][c + 1].rgbtGreen;
            GyB = image2[r + 1][c - 1].rgbtBlue  + 2 * image2[r + 1][c].rgbtBlue  + image2[r + 1][c + 1].rgbtBlue  -
                  image2[r - 1][c - 1].rgbtBlue  - 2 * image2[r - 1][c].rgbtBlue  - image2[r - 1][c + 1].rgbtBlue;

            gR = (int)round(sqrt((double)(GxR * GxR + GyR * GyR)));
            if (gR > 0xFF)
            {
                gR = 0xFF;
            }
            
            gG = (int)round(sqrt((double)(GxG * GxG + GyG * GyG)));
            if (gG > 0xFF)
            {
                gG = 0xFF;
            }
            
            gB = (int)round(sqrt((double)(GxB * GxB + GyB * GyB)));
            if (gB > 0xFF)
            {
                gB = 0xFF;
            }
            
            image[r - 1][c - 1].rgbtRed = gR;
            image[r - 1][c - 1].rgbtGreen = gG;
            image[r - 1][c - 1].rgbtBlue = gB;
        }
    }
    
    free(image2);
    return;
}
